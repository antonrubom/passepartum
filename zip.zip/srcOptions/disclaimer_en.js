document.write('\
<div class="disclaimer-wrapper">\
<h1>Disclaimer</h1>\
<div class="text"> \
<b>Storage</b>\
<br>\
Your login data is stored <b>locally</b> and <b><a href="https://developer.chrome.com/docs/extensions/reference/storage/" target="_blank">unencrypted</a></b> somewhere in the files \
for this Chrome extension. This means anybody with access to this computers local storage can potentially \
access your password, even if that access is a remote one (like Team Viewer or potential spyware). \
It is not synchronized via cloud storage, which means it cannot be scooped \
by somebody watching your network traffic. \
<br>\
<br>\
<b>Why do we compare the security to that of the chrome/edge password autofill feature?</b>\
<br>\
Because if someone would go to the login page of moodle and your passwords gets autofilled, \
it is a matter of a few clicks to copy the password out of the password window. \
<br>\
<br>\
<b>The devs</b>\
<br>\
Non of the people writing this extension have a background in information security, so we cannot \
promise a flawless experience. However all of the developers use this extension and trust it\'s basic functionality.\
<br>\
<br>\
<b>What if you don\'t provide the login data?</b>\
<br>\
You can use this extension even without providing your TUM login. It will still save you one or \
two click here and there - that is the whole point after all. \
\
<br>\
<br>\
<div class="small-text">\
<a target="_blank" href="https://icons8.com/icon/113135/schlüssel">Schlüssel</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>\
</div>\
</div></div>\
\
')
